import { Link } from 'react-router-dom';
import { Users, MapPin, Star } from 'lucide-react';
import { motion } from 'framer-motion';

const HallCard = ({ hall }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="group bg-white rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-50 flex flex-col h-full relative"
    >
      <div className="relative h-72 overflow-hidden">
        <img 
          src={hall.images[0] ? (hall.images[0].startsWith('http') ? hall.images[0] : `http://localhost:5000/${hall.images[0].replace(/\\/g, '/')}`) : 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80'} 
          alt={hall.name}
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        <div className="absolute top-6 left-6">
          <span className="px-4 py-2 bg-white/90 backdrop-blur-md rounded-2xl text-[10px] font-black text-primary shadow-xl uppercase tracking-[0.2em]">
            {hall.district}
          </span>
        </div>
        
        <div className="absolute bottom-6 right-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
          <div className="bg-primary text-white px-5 py-3 rounded-2xl font-black shadow-2xl flex flex-col items-end">
            <span className="text-2xl">{hall.price.toLocaleString()}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-80">so'm / kishi</span>
          </div>
        </div>
      </div>
      
      <div className="p-8 flex flex-col flex-1 space-y-6">
        <div>
          <h3 className="text-2xl font-black text-gray-900 group-hover:text-primary transition-colors line-clamp-1 mb-2">
            {hall.name}
          </h3>
          <div className="flex items-center text-gray-400 gap-2">
            <MapPin className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider line-clamp-1">{hall.address}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-2xl text-secondary">
            <div className="p-2 bg-white rounded-xl shadow-sm">
              <Users className="w-4 h-4" />
            </div>
            <span className="text-xs font-black">{hall.capacity} kishi</span>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-2xl text-secondary">
            <div className="p-2 bg-white rounded-xl shadow-sm">
              <Star className="w-4 h-4 text-primary" />
            </div>
            <span className="text-xs font-black">Premium</span>
          </div>
        </div>

        <Link 
          to={`/hall/${hall._id}`}
          className="w-full bg-secondary hover:bg-gray-900 text-white text-center py-5 rounded-[1.5rem] font-black tracking-widest text-xs transition-all active:scale-95 shadow-xl shadow-gray-200 hover:shadow-secondary/30"
        >
          Batafsil ko'rish
        </Link>
      </div>
    </motion.div>
  );
};

export default HallCard;
