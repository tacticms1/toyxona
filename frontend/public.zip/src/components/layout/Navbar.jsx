import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Home, LogIn, UserPlus, LogOut, LayoutDashboard, User } from 'lucide-react';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getDashboardPath = () => {
    if (user.role === 'admin') return '/admin';
    if (user.role === 'owner') return '/owner';
    return '/customer';
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-100">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="p-2 bg-primary rounded-xl rotate-3 group-hover:rotate-0 transition-transform">
            <Home className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-black text-gray-900 tracking-tight">
            To'y<span className="text-primary">Xona</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-gray-600 hover:text-primary font-semibold transition-colors">
            To'yxonalar
          </Link>
          <Link to="/about" className="text-gray-600 hover:text-primary font-semibold transition-colors">
            Biz haqimizda
          </Link>
          <Link to="/contact" className="text-gray-600 hover:text-primary font-semibold transition-colors">
            Bog'lanish
          </Link>
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-6">
              <Link 
                to={getDashboardPath()} 
                className="flex items-center gap-2 text-gray-700 hover:text-primary font-bold transition-colors"
              >
                <LayoutDashboard className="w-5 h-5" />
                <span>Kabinet</span>
              </Link>
              
              <div className="h-8 w-[1px] bg-gray-200"></div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center text-primary font-bold shadow-inner">
                  {user.firstName ? user.firstName[0].toUpperCase() : 'U'}
                </div>
                <button onClick={handleLogout} title="Chiqish" className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Link to="/login" className="px-6 py-2.5 font-bold text-gray-700 hover:text-primary transition-colors">
                Kirish
              </Link>
              <Link to="/register" className="bg-primary hover:bg-pink-800 text-white font-bold px-8 py-3 rounded-xl transition-all active:scale-95 shadow-lg shadow-primary/20">
                Ro'yxatdan o'tish
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
