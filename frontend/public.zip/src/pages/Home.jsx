import { useState, useEffect } from 'react';
import api from '../api/axios';
import HallCard from '../components/halls/HallCard';
import { Search, SlidersHorizontal, ArrowUpDown, Loader2 } from 'lucide-react';

const Home = () => {
  const [halls, setHalls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [district, setDistrict] = useState('');
  const [sort, setSort] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  const [error, setError] = useState(null);

  const fetchHalls = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        search,
        district,
        sort,
        minPrice,
        maxPrice
      });
      const res = await api.get(`/halls?${params.toString()}`);
      setHalls(res.data);
    } catch (err) {
      console.error(err);
      setError('Ma’lumotlarni yuklashda xatolik yuz berdi. Backend va Ma’lumotlar bazasi ulanishini tekshiring.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHalls();
  }, [district, sort]);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchHalls();
  };

  return (
    <div className="space-y-8">
      {/* Hero Section with Background Gradient */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-white to-pink-50 rounded-[2rem] p-8 md:p-20 shadow-inner">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-72 h-72 bg-pink-200/20 rounded-full blur-3xl"></div>
        
        <div className="relative text-center max-w-4xl mx-auto">
          <span className="inline-block px-4 py-1.5 mb-6 text-sm font-bold tracking-widest text-primary uppercase bg-pink-100 rounded-full">
            Eng sara to'yxonalar
          </span>
          <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 leading-tight">
            Orzungizdagi <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-pink-600">To'yxonani</span> Toping
          </h1>
          <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-2xl mx-auto">
            Hashamatli va shinam maskanlar. Tasdiqlangan to'yxonalarni shaffof narxlar va darhol band qilish imkoniyati bilan tanlang.
          </p>
          
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-3 p-2 bg-white rounded-2xl shadow-2xl border border-gray-100 max-w-2xl mx-auto">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                className="w-full pl-12 pr-4 py-4 bg-transparent outline-none text-gray-700"
                placeholder="To'yxona nomini kiriting..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button type="submit" className="bg-primary hover:bg-pink-800 text-white font-bold px-10 py-4 rounded-xl transition-all active:scale-95 shadow-lg shadow-primary/20">
              Qidirish
            </button>
          </form>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Advanced Filters Sidebar */}
        <aside className="w-full lg:w-80 space-y-8">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-50 space-y-8 sticky top-28">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3 font-black text-gray-900 uppercase tracking-widest text-sm">
                <SlidersHorizontal className="w-5 h-5 text-primary" />
                Filtrlar
              </div>
              {(district || sort || minPrice || maxPrice) && (
                <button 
                  onClick={() => {
                    setDistrict('');
                    setSort('');
                    setMinPrice('');
                    setMaxPrice('');
                  }}
                  className="text-[10px] font-bold text-primary hover:underline uppercase tracking-tighter"
                >
                  Tozalash
                </button>
              )}
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Hudud</label>
                <div className="relative">
                  <select 
                    className="w-full bg-gray-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                  >
                    <option value="">Barcha tumanlar</option>
                    {['Yunusobod', 'Chilonzor', 'Mirzo Ulugbek', 'Mirobod', 'Yakkasaroy', 'Shayxontohur', 'Olmazor', 'Sergeli', 'Uchtepa', 'Bektemir', 'Yashnobod', 'Yangihayot'].map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                  <ArrowUpDown className="absolute right-5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300 pointer-events-none" />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Narx Oralig'i (so'm)</label>
                <div className="grid grid-cols-2 gap-3">
                  <input 
                    type="number" 
                    placeholder="Min" 
                    className="w-full bg-gray-50 border-none rounded-2xl px-4 py-4 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                  />
                  <input 
                    type="number" 
                    placeholder="Max" 
                    className="w-full bg-gray-50 border-none rounded-2xl px-4 py-4 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Saralash</label>
                <div className="relative">
                  <select 
                    className="w-full bg-gray-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    value={sort}
                    onChange={(e) => setSort(e.target.value)}
                  >
                    <option value="">Standart</option>
                    <option value="price_asc">Narx: Arzonroq</option>
                    <option value="price_desc">Narx: Qimmatroq</option>
                    <option value="capacity_desc">Sig'imi: Kattaroq</option>
                  </select>
                  <ArrowUpDown className="absolute right-5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300 pointer-events-none" />
                </div>
              </div>
            </div>

            <button 
              onClick={fetchHalls}
              className="w-full bg-gray-900 hover:bg-primary text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all active:scale-95 shadow-xl shadow-gray-100 hover:shadow-primary/20"
            >
              Filtrni qo'llash
            </button>
          </div>
        </aside>

        {/* Hall Grid */}
        <div className="flex-1 space-y-8">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-sm font-black text-gray-400 uppercase tracking-[0.3em]">
              Natijalar: <span className="text-gray-900">{halls.length} ta to'yxona</span>
            </h2>
          </div>
          
          {loading ? (
            <div className="flex flex-col justify-center items-center h-96 space-y-4 bg-white rounded-[3rem] border border-gray-50 shadow-sm">
              <Loader2 className="w-12 h-12 animate-spin text-primary" />
              <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Qidirilmoqda...</p>
            </div>
          ) : halls.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {halls.map(hall => (
                <HallCard key={hall._id} hall={hall} />
              ))}
            </div>
          ) : (
            <div className="text-center py-32 bg-white rounded-[3rem] border border-gray-50 shadow-sm space-y-6">
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
                <Search className="w-10 h-10 text-gray-200" />
              </div>
              <div className="space-y-2">
                <p className="text-2xl font-black text-gray-900">Hech narsa topilmadi</p>
                <p className="text-gray-400 max-w-xs mx-auto">Qidiruv mezonlarini o'zgartirib ko'ring yoki barcha to'yxonalarni ko'ring.</p>
              </div>
              <button 
                onClick={() => {
                  setSearch('');
                  setDistrict('');
                  setMinPrice('');
                  setMaxPrice('');
                  setSort('');
                  fetchHalls();
                }}
                className="text-primary font-black uppercase tracking-widest text-xs hover:underline"
              >
                Barcha to'yxonalar
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
